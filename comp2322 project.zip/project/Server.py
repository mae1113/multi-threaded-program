# Implements a simple HTTP Server
import socket
import os   
import time

def get_file_type(filename):
    # Determine the file type based on the file extension
    if filename.endswith('.txt'):
        return 'text/plain'
    elif filename.endswith('.jpg', '.jpeg','.png', '.gif'):
        return 'image/*'
    else:
        return None # Default type for unknown files

def generate_http_response(status_code, headers, body = ''):
    # Generate the HTTP response header
    response_line = f'HTTP/1.1 {status_code}\n'
    headers = ''.join([f'{key}:{value}\n' for key, value in headers.items()])
    blank_line = '\n'
    return response_line + headers + blank_line + body

def handle_if_modified_since(headers, filepath):
    # Check if the file has been modified since the given date
    if 'If-Modified-Since' in headers:
        last_modified = time.strtime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(os.path.getmtime(filepath)))
        if headers['If-Modified-Since'] == last_modified:
            return generate_http_response('304 Not Modified', {})
    return None

def handle_connection_header(client_connection, headers):
    # Check if the connection header is present
    if 'Connection' in headers:
        if headers['Connection'] == 'close':
            client_connection.close()
        else:
            client_connection.settimeout(None)  # Set a timeout for the connection

# Handle the HTTP request
def handle_request(request):
    
    # Parse HTTP headers
    headers = request.strip().split('\n')

    if len(headers) == 0 or len(headers[0].split()) < 2:
        return generate_http_response('400 Bad Request', {})
    
    fields = headers[0].split()
    request_type = fields[0]  
    filename = fields[1]
    filepath = filename.strip('/')
	
    # Parse the request type
    if not request:
        raise ValueError()

    if os.path.exists(filepath):
        
        if os.access(filepath, os.R_OK):
            if request_type == 'GET':
                # Handle GET request
                if filename == '/':
                    filename = '/index.html'
                
                response = handle_if_modified_since(headers, filepath)
                if response:
                    return response
        
                file_type = get_file_type(filepath)
                if not file_type:
                # Check if the file type is supported
                    return generate_http_response('415 Unsupported Media Type', {})
            
                with open('httpdoc' + filepath) as fin:
                    content = fin.read()
                headers.update({    
                    'Content-Type': file_type,
                    'Content-Length': str(len(content)),
                    'Last-Modified': time.ctime (os.path.getmtime(filepath)),
                })

                fin.close()
                return generate_http_response('200 OK', headers, content)
            
            elif request_type == 'HEAD':
            # Handle HEAD request
                headers = {
                    'Content-Type': file_type,
                    'Content-Length': str(os.path.getsize(filepath)),
                    'Last-Modified': time.ctime (os.path.getmtime(filepath)),
                }
                return generate_http_response('200 OK', headers, '')
        
            elif FileNotFoundError:
                return generate_http_response('404 Not Found', {})
        
            elif ValueError:
                return generate_http_response('400 Bad Request', {})
    
    elif not os.path.exists(filepath):
        # Check if the file exists
        return generate_http_response('403 Forbidden', {})

    else:
        return generate_http_response('400 Bad Request', {})		    

# Define socket host and port
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8000

# Create socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((SERVER_HOST, SERVER_PORT))
server_socket.listen(5)
print('Listening on port %s ...' % SERVER_PORT)

while True:
    # Wait for client connections
    client_connection, client_address = server_socket.accept()

    # Get the client request
    request = client_connection.recv(1024).decode()
    print('request:\n{request}')
	
    # Send HTTP response
    response = handle_request(request)
    client_connection.sendall(response.encode())

    # Close connection
    client_connection.close()

# Close socket
server_socket.close()
