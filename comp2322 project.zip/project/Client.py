# Implements a simple HTTP client
import socket

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8000

def send_http_request(request_type, file_path, connection_type):
    # Create a socket object
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        try:
            # Connect to the server
            client_socket.connect((SERVER_HOST, SERVER_PORT))

            # Define the request type and file path
            request = f'{request_type} {file_path} HTTP/1.1\r\n'
            request += f'Host: {SERVER_HOST}\r\n'
            request += f'Connection: {connection_type}\r\n'

            request += '\r\n'  # End of headers

            # Send the request to the server
            client_socket.sendall(request.encode())

            # Receive the response from the server
            response = client_socket.recv(1024)
    
            # Print the server response
            print('Server response:\n')
            print(response.decode())
  
            # Close the socket connection
            client_socket.close()
        except socket.error as e:
            print(f"Socket error: {e}")

# Example usage
if __name__ == '__main__':
    # Send a GET request to the server
    send_http_request('GET', '/helloworld.html', 'keep-alive')
    
